This IPython notebook eigvalues.ipynb does not require any additional
programs.
